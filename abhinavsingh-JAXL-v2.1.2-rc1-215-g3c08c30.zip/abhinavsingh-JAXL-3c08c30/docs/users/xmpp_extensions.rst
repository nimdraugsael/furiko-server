XMPP Extensions (XEP)
=====================

Writing Custom XMPP Extension
-----------------------------

Entity Discovery
----------------

Multi-User Chat
---------------

Direct MUC Invitation
---------------------

Publish-Subscribe
-----------------

In-Band User Registration
-------------------------

External Jabber Component
-------------------------

Entity Capabilities
-------------------

Delayed Delivery
----------------

XMPP Over HTTP (Bosh)
---------------------
