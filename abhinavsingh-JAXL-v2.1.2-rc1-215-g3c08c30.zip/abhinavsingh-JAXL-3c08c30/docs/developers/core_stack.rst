Core Stack
==========
That has a paragraph about a main subject and is set when the '='
is at least the same length of the title itself.

Main Event Loop
----------------

Finite State Machine
--------------------

TCP/IP Socket Client
--------------------

TCP/IP Socket Server
--------------------

Event Emitter
-------------

Streaming XML Parser
--------------------

XML Objects
-----------

Timed Job Dispatcher
--------------------

Inter-Process Communication (IPC)
---------------------------------

Remote Shell & Debug Console
-----------------------------